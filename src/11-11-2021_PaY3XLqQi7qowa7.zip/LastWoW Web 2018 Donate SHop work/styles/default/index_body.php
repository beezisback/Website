<?php exit; ?> 
<div id="menu">
<ul>
<li class="active">News | </li> <li><a href="register.wow">Register Account</a> | </li> <li><a href="accounts.wow">Account Manager</a> | </li> <li><a href="connection.wow">Connection guide</a> | </li> <li><a href="statistics.wow">Statistics</a> | </li> <li><a href="#">About us</a> |</li> <li><a href="/forum" target='_blank'>Forum</a></li>
</ul>
</div>
<div id="content">
<p class="info"><big>
<script type="text/javascript">
var d = new Date()
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
document.write(monthname[d.getMonth()] + " ")
document.write(d.getDate() + ", ")
document.write(d.getFullYear())
</script>
<?php $date = date(M); ?> </big> <span><a href="register.wow">Register Now</a> and take a look at our <a href="./connection.wow">Connection guide</a> </p>

<!--
<div class="post">
<div class="title">
<h1><a href="#">Server Update</a> <span>( 24/11/2016 )</span> </h1>
</div>
<div class="body">
Hello friends server will be stopped by 16:00 to 18:00 Server time for update.
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b> </div>
</div>
-->
	<center>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- mp3auto -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7001804713907847"
     data-ad-slot="5448241613"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>


<div class="post">
<div class="title">
<h1><a href="#">Zul'aman General Changelog</a> <span>( 13/12/2018 )</span> </h1>
</div>
<div class="body">
<font size="2">* Reincrease Timer by 1 Minute

Sources say 20min, 21 looks nicer as its 20 for one minute

* Some more Zul'Aman General polishing

Introduced some enums
Scout Movement causes issues with UNIT_FLAG_DISABLE_MOVE we need to drop
waypoint movement as in Sunwell
Fixed Akilzon Gauntlet due to left over Reset() on Kill Lookout
Polished Time Loot Events a little bit to match with alot of new
introduced GOs</font>

<!--<img src="https://blizzard.justnetwork.eu/files/2015/04/WoW-Archimonde-1110x400.jpg" width="565" height="270" title="Raid Hyjal LastWoW 2.4.3" />-->
<br/>
Sincerely, <b>Last WoW Staff</b>
</div>
</div>

<div class="post">
<div class="title">
<h1><a href="#">New realmlist</a></h1>
</div>
<div class="body">
Hello we already have new Realmlist <b>set realmlist logon.lastwow.ga</b> and <b> 
<br/>
set realmlist 35.28.185.127</b>
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>

<div class="post">
<div class="title">
<h1><a href="#">Update Changelog</a> <span>( 29/11/2018 )</span> </h1>
</div>
<div class="body">

<b>Changelog</b> <font color="#6d0d00">( 29/11/2018 )</font>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Script: Karazhan fix for Nightbane - Time taken to land during e ncounter reduced to normal time
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fixed duration of item 23379 (Cinder Bracers) from MidSummer Festival
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix 2set Tier 4 Resto Druid proc
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: miscelleanous guardian pets updates
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: update quests relations
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=872">http://ru.wowhead.com/quest=872</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/npc=4046">http://ru.wowhead.com/quest=5041</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix swapped cloth donation quests
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: sequence cloth donations
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Lava Burst (Ragnaros)
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Fixed model size of NPCs
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://ru.wowhead.com/npc=4046">http://ru.wowhead.com/npc=4046</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://ru.wowhead.com/npc=11117">http://ru.wowhead.com/npc=11117</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Fixed quest
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8312">http://ru.wowhead.com/quest=8312</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8359/flexing-for-nougat">http://ru.wowhead.com/quest=8359/flexing-for-nougat</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8358">http://ru.wowhead.com/quest=8358</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8360/dancing-for-marzipan">http://ru.wowhead.com/quest=8360/dancing-for-marzipan</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8354">http://ru.wowhead.com/quest=8354</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8356">http://ru.wowhead.com/quest=8356</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8355/incoming-gumdrop">http://ru.wowhead.com/quest=8355/incoming-gumdrop</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8353">http://ru.wowhead.com/quest=8353</a>
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=8357">http://ru.wowhead.com/quest=8357</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Captain Dirgehammer, Lady Palanseerare level 55, not 65
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix some AreaTriggers
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Stones of Binding: aligned spawntime with Servants and set default flags to 4 to make it usable by players
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=2681">http://ru.wowhead.com/quest=2681</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix Gnomeregan Teleport
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix faction <a href="http://ru.wowhead.com/npc=80">http://ru.wowhead.com/npc=80</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fixed faction of GO 179784 in Blackwing Lair
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: improved quest 308
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=308/distracting-jarven">http://ru.wowhead.com/quest=308/distracting-jarven</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fixed spawn time of creature 11489 in Dire Maul
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://ru.wowhead.com/npc=11489">http://ru.wowhead.com/npc=11489</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Added missing rare spawns in Zul'Farrak
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://www.wowhead.com/npc=10080#comments">http://www.wowhead.com/npc=10080#comments</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://www.wowhead.com/npc=10081#comments">http://www.wowhead.com/npc=10081#comments</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td><a href="http://www.wowhead.com/npc=10082#comments">http://www.wowhead.com/npc=10082#comments</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fixed some quest relations in Darkshore (Data YTDB)
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix incorrect Tailoring requirement 
<br/>
<td><img src="styles/default/Images/quest.gif" width="20" height="20" alt="Fix" /></td><a href="http://ru.wowhead.com/quest=3385/the-undermarket">http://ru.wowhead.com/quest=3385/the-undermarket</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix Rune-Inscribed Parchment text
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: fix vanilla boss immunities
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/DB: Fixed damage of NPCs 5317, 5319 & 5320
<br/>
<b>Changelog</b> <font color="#6d0d00">( 29/11/2018 )</font>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Spells: Fix spell "Stuck", it should teleport you to HS location
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Corpses: Fix visibility of corpses after a server restart
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Corpse: Correctly destroy corpse so you can see bones and
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Loot Fix some issues with loot
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Pet: Fix Eyes of the Beast crash
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Fixes a removed from world crash and others
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Fixes pet is not following player after being possessed
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Fixes pet spells/abilities are removed after being possessed
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Fixes re-logging while channeling Eyes of the Beast
<br/>
<b>Changelog</b> <font color="#6d0d00">( 29/11/2018 )</font>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> [Core/Cleanup] Remove duplicate check in Creature::IsImmuneToSpell
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> [Core/Stability] Fix another crash (nullptr dereference)
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> [Core/Crashes] Fix a crash (reported by Stepa)
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> [Spells/Chains] Fix #1436 - Broken SpellChains
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Commands: Start command should teleport you to your races starti
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Battlegrounds: Revive pets on player revive in battlegrounds
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Fixed creature waypoint movement bug
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Creatures: Don't add threat to an evading unit
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> DB/Waypoints: Add a couple of waypoints
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Stop corpses of flying creatures from moving
<br/>
<b>Changelog</b> <font color="#6d0d00">( 29/11/2018 )</font>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Spell: Fix spell of Orb of Translocation
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Spells: Fix vanish not applying stealth
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Player: fix player kicking
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Arena: arena rating display corrected
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Player: Fix AFK/DND/SYSTEM spam for addon whispers
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Opcodes: Fix MSG_INSPECT_HONOR_STATS
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Arena: add inspect hostile checks
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Movement: Update client control state when on taxi
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> Core/Unit: Blizzlike NPC crit adjustments
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> <a href="http://www.wowhead.com/quest=6624/triage">[Quest] Triage Alliance Fix.</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> <a href="http://www.wowhead.com/quest=6622/triage">[Quest] Triage Horde Fix.</a>
<br/>
<td><img src="styles/default/Images/checkmark.png" alt="Fix" /></td> <a href="http://www.wowhead.com/quest=9977/the-ring-of-blood-the-final-challenge">Nagrand [Quest] The Ring of Blood: The Final Challenge Fix.</a>
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>

<!--
<div class="post">
<div class="title">
<h1><a href="#">To all</a> <span>( 04/10/2016 )</span> </h1>
</div>
<div class="body">
<font color="red">Hello. We want to kindly ask you to stop asking GM for free levels or items. Every player who decide to do this after this message will be muted for 24 hours. Best Regards.</font>
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>


<div class="post">
<div class="title">
<h1><a href="#">Last WoW</a> <span>( 19/09/2016 )</span> </h1>
</div>
<div class="body">
<img src="/styles/default/Images/banners/arens2.JPG" width="565" height="240" /></a>
<br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>

<div class="post">
<div class="title">
<h1><a href="#">Server Maintenance</a> <span>( 11/05/2016 )</span> </h1>
</div>
<div class="body">
As you already know, occasionally it is necessary to stop all running things and do short or long term prophylaxis. This is necessary to be a server in good condition and all new things have been added.
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>

<div class="post">
<div class="title">
<h1><a href="#">New Changelog</a> <span>( 08/05/2016 )</span> </h1>
</div>
<div class="body">
A new Changelog has been pushed to the Server, including several important fixes and changes.
<br/><br/>
The full list of fixes can be found in <a href="forum/viewforum.php?f=51">this forum thread</a>, as well as some details about our immediate future plans.
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b>
</div>
</div>
-->

<div class="post">
<div class="title">
<h1><a href="#">Vote every day!</a> <span>( 20/11/2018 )</span> </h1>
</div>
<div class="body">
Do not forget to vote every 12  hours and get epic items thank you.
<br/><br/>
Sincerely, <b>Last WoW TBC Server</b> </div>
</div>

	<center>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- mp3auto -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7001804713907847"
     data-ad-slot="5448241613"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
</div>
</div>