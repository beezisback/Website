<?php exit; ?><div class="post">
<div class="post_body3" align="left">{content}</div>
</div>