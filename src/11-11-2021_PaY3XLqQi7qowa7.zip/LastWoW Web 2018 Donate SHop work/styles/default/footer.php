<?php exit; ?> 
<!--<-->
</div>
</div>
</br>
</br>
<div id="footer">
<p>2018. Last WoW
<a title="TBC server" href="#">TBC Server</a>
</p>
<ul>
<li><a href="./">News</a> |</li>
<li><a href="register.wow">Register</a> |</li>
<li><a href="accounts.wow">Account Manager</a> |</li>
<li><a href="#">Tools</a> |</li>
<li><a href="statistics.wow">Statistics</a> |</li>
<li><a href="#">About Us</a> |</li>
<li><a href="#">Forum</a></li>
</ul>
</div>
</div>
</div>
</body>
</html>