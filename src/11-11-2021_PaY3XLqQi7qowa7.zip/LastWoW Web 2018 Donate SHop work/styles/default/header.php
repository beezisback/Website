<?php exit; ?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>{title}</title>
{stylesheet}
<link rel="shortcut icon" href="favicon.ico" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="http://cdn.cavernoftime.com/api/tooltip.js"></script>
<meta name="google-site-verification" content="J-6zi0vdaYC6Lh8vM1Kn-sXSi4j72uS13wdxj48neSU">
<meta name="description" content="[2.4.3 version][Arena Season Rankings] [Battlegrounds work] [Lag-free][Great Uptime] [PvP and Arena Ranks] [Season 4 items] [Scripted Instances] [Vote and be Rewarded!] [Rates:15x Xp 20x Quest 18x Drop 15x Rep 20x Gold 2x Honor 2x Arena]">
<meta name="keywords" content="lastwow, wow, server wow, private server wow, private server, wow private server, wow gratis, free wow, play wow for free, server season 4, burning crusade, world of warcraft, best wow server, tbc, 2.4.3 server, pre-tbc titles, server with events, best tbc server, tbc server, burning crusade server, blizzlike server, high-rate server, high rate server, 15x rates">
<script async src="//pagead2.googlesyndication.com/
pagead/js/adsbygoogle.js"></script>
<script>
(adsbygoogle = window.adsbygoogle || []).push({
google_ad_client: "pub-7001804713907847",
enable_page_level_ads: true
});
</script>
<script src='js/snow.js' type="text/javascript"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var snoweffect = {"show":"1","flakes_num":"30","falling_speed_min":"1","falling_speed_max":"3","flake_max_size":"20","flake_min_size":"10","vertical_size":"800","flake_color":"#efefef","flake_zindex":"100000","flake_type":"#10053","fade_away":"1"};
/* ]]> */
</script>
<script src='js/snows.js' type="text/javascript"></script>
</head>

<body>
<script language="Javascript">
function validate(valor,tipo){
	var regex=/^[A-Za-z0-9-@.]+$/; 
	if(regex.test(valor)) {
		document.getElementById(tipo).src = 'styles/default/Images/ok.png';
		document.getElementById(tipo).style.display = 'block';
		return true;
	} else {
		document.getElementById(tipo).src = 'styles/default/Images/error.png';
		document.getElementById(tipo).style.display = 'block';
		return false;
	}
}
</script>
<div id="container">
<div id="header">
<p class="info cut"><b>Version:</b> 2.4.3 TBC <b>Rates:</b> 15x Exp, 20x Quest, 15x Drop, 15x Reputation, 20x Gold, 2x Honor, 2x Arena</p>
<div class="logo"> <a href="/" class="indent">LastWOW</a> </div>
<!-- login Start -->
<!-- if(link_guest) -->
	 <form method="post" target=""  action="login.wow" id="login">
      <span>Log In or <a href="register.wow">Join to Lastwow.ga</a></span>

      <fieldset>

        <input type="text" class="field" name="username" value="User" onclick="this.value=''"/>

        <input type="password" class="field" name="password" value="Password" onclick="this.value=''" />
		
        <input type="submit" class="send" name="action" value="" />
        
      </fieldset>

    </form>
<!-- else(link_guest) -->	
<!-- endif(link_guest) -->
<!-- login end -->
<h2>Server statistics</h2>
</div>
<div id="wrapper">
<div id="all">
<div id="colz">