<?php
//This file is part of PayPal Donation Module copyright by AXE at www.web-wow.net
$paypalurl="www.paypal.com"; //change for sandbox testing
$paypalemail="frinci6666@abv.bg";
$paypalcurrecy="USD";
$paypalcurrecy_symbol="$";
?>