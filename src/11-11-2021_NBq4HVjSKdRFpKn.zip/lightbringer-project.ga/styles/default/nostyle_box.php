<?php exit; ?>
<div>
{content}
</div>