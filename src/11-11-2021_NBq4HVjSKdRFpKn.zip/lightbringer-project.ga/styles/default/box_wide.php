<?php exit; ?>
<div id="content">

            <div class="post">

              <div class="title">

                <h1><a href="#">{content_title}</a></h1>

              </div>

              <div class="body">
			  

			  
			  
	{content}

</div>
</div>
</div>
</div>
