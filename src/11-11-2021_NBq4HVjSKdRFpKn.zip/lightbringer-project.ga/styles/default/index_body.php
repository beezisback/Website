<?php exit; ?> 
<div id="alert-container" class="sticky-top"></div>
<section class="container dark-content">
    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="/">News</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/changelog">Changelog</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="news-posts-list">
        <div class="row">
            <div class="col-lg-8">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane show active">
                        <div class="row">
<div class="col-md-12">


								 <div class="post">
                <a class="title" href="/news/11">Important! TBC Release</a>
            <div class="date">Tuesday, 11 December 2019</div>
            <div class="description"><div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/IBHL_-biMrQ"></iframe>
</div>
<p>Coming soon our new realm tbc!</p></div>
                <a class="read-more" href="/news/11">
                    Read more
                    <i class="fa fa-chevron-right"></i>
                </a>
        </div>


        <div class="post">
                <a class="title" href="/news/11">Trailer and release date</a>
            <div class="date">Tuesday, 11 December 2019</div>
            <div class="description"><div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/vlVSJ0AvZe0"></iframe>
</div>
<p>Check out our latest video in which you will find more information about the project and its features. We're also happy to announce the server will be released in February 2020!</p></div>
                <a class="read-more" href="/news/11">
                    Read more
                    <i class="fa fa-chevron-right"></i>
                </a>
        </div>
    </div>
    

                        </div>
                    </div>
                </div>
            </div>
			
			
          

