<div id="content">
<p class="info"><big>
<script type="text/javascript">
var d = new Date()
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December")
document.write(monthname[d.getMonth()] + " ")
document.write(d.getDate() + ", ")
document.write(d.getFullYear())
</script>
<?php $date = date(M); ?> </big>  </p>
<div class="post">
<div class="title">
<h1><a href="#">Account Manager</a></h1>
</div>
<div class="body">

