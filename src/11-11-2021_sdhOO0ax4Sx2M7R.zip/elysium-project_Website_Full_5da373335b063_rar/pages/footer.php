<footer id="footer">
<div class="container">
<div class="row clearfix">
<div class="column">
<div id="footer-copy" class="wow fadeInUp">
&copy; 2018 - 2019 <br />
<a href="?p=account">Nefelin-WoW Project, WoTlk Legacy Server</a> <a class="legals" href="#">Contact us - About us</a> <a class="legals" href="#">Refund policy / private policy</a> </div>
</div>
</div>
</div>
</footer>

<script type="text/javascript" src="/themes/nefelin/js/jquery-2.1.0.min.js"></script>
<script type="text/javascript" src="/themes/nefelin/js/custom.js"></script>

