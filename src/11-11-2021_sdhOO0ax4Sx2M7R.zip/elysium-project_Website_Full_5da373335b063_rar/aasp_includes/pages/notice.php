<?php session_destroy(); ?>
<?php echo $_GET['e']; ?>
<hr/>
<a href="index.php" title="Log in again">Click here to Log In again</a>
