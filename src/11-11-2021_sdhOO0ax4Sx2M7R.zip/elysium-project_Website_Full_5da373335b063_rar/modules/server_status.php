<?php if($GLOBALS['serverStatus']['enable']==TRUE) 
{ ?>
<span id="server_status">

</span>
<?php } ?>