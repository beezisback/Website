<?php $page = new page; ?>
<div class="box_right_title"><?php echo $page->titleLink(); ?> &raquo; Tools</div>
<input type="submit" value="Clear Vote shop" onclick="clearShop('vote')"/>  &nbsp; 
This will clear all items from the vote shop<br/><br/>
<input type="submit" value="Clear Donation shop" onclick="clearShop('donate')"/> &nbsp;  
This will clear all items from the donation shop