<?php
$rp_enable = false; //If set to 'true', a link to the Refund Policy will be displayed on the Donation page.

$rp_message = "Write your refund policy here..."; //Here's your message, HTML IS allowed.
?>
