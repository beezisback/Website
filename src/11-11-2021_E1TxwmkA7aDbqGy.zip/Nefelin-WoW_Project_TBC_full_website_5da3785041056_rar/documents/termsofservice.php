<?php
$tos_enable = false; //If set to 'true', a link to the Refund Policy will be displayed on the Registration page-

$tos_message = "Write your Terms of Service here..."; //Here's your message, HTML IS allowed.
?>
