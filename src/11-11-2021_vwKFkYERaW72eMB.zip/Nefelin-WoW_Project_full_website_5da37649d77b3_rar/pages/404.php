<h2>Page not found</h2>
Sorry, but the requested page was not found!<br/><hr/>
<a href="?p=home">&raquo; Back to the homepage</a><br/>
<a href= "javascript:history.go(-1)">&raquo; Back to the previous page</A>