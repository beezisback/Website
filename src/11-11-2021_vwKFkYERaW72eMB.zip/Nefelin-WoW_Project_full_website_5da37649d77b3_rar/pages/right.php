<div class="container">
<div class="row">
<aside class="sidebar pull-right wow bounceInRight">

<div class="twitter-widget-holder js-pretty-scroll-light">
<a href="https://discord.gg/USnQf3X"><img src="/images/discord.png" width="270" height="106"></a>
</div>


<div class="facebook-widget-holder js-pretty-scroll-light">
<div class="fb-container">
<div class="fb-page" data-href="" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false" data-height="3000" data-width="350">
<blockquote cite="" class="fb-xfbml-parse-ignore">
<a href="">Nefelin-WoW Project</a>
</blockquote>
</div>
</div>
</div>
</aside>