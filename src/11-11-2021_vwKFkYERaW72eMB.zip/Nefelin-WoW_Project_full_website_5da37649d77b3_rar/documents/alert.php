<?php

$alert_enabled = false;

$alert_message = "We're currently doing some minor updates on the website. You may experience some parts disturbing in the meantime. <br/>
				  We sincerely apologize for this.";

?>

